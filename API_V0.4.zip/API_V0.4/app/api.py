from fastapi import FastAPI, HTTPException, status, Depends
from sqlalchemy.orm import session
from typing import Optional

from .database import SessionLocal, engine
from . import crud, schemas, models

models.Base.metadata.create_all(bind=engine)

app = FastAPI()  

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get('/', tags=['Root'],
    status_code=status.HTTP_200_OK
)
async def read_root() -> str:
    response = "Welcome on my API"
    return response


@app.post('/doctors/create', tags=['Doctors'], summary="Creation of a doctor in the database",
    response_model = schemas.DoctorDb,
    response_model_exclude = {'password', 'patients_id'}, 
    status_code = status.HTTP_201_CREATED, 
    response_description = "Creation of a doctor in the database, successful." 
)
async def doctors_create(request: schemas.DoctorCreate, db: session = Depends(get_db)) -> dict:
    response = crud.doctors_create(request, db)
    return response


@app.get('/doctors/read/all', tags=['Doctors'], summary="Retrieving all doctors in the database",
    status_code = status.HTTP_200_OK, 
    response_description = "Retrieving all doctors in the database, successful." 
)
async def doctors_read_all(db: session = Depends(get_db)) -> dict:
    response = crud.doctors_read_all(db)
    return response

@app.get('/doctors/read/{id}', tags=['Doctors'], summary="Retrieving doctor by his id in the database",
    response_model = schemas.DoctorDb,
    status_code = status.HTTP_200_OK,
    response_model_exclude = {'password', 'id'}, 
    response_description = "Retrieving doctor by his id in the database, successful." 
)
async def doctors_read_by_id(id: int, db: session = Depends(get_db)) -> dict:
    response = crud.doctors_read_by_id(id, db)
    return response
     

@app.delete('/doctors/delete/{id}', tags=['Doctors'], summary="Removal of the doctor by his identifier in the database",
    status_code = status.HTTP_204_NO_CONTENT,
    response_description = "Removal of the doctor by his identifier in the database, successful." 
)
async def doctors_delete_by_id(id: int, db: session = Depends(get_db)) -> dict:
    response = crud.doctors_delete_by_id(id, db)
    return response

@app.put('/doctors/updated/{id}', tags=['Doctors'], summary="...",
    status_code = status.HTTP_204_NO_CONTENT,
    response_description = "..." 
)
async def doctors_updated_by_id(id: int, request: schemas.DoctorBase, db: session = Depends(get_db)) -> dict:
    response = crud.doctors_updated_by_id(id, request, db)
    return response