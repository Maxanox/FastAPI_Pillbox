from sqlalchemy.orm import session
from fastapi import HTTPException, status
from fastapi.encoders import jsonable_encoder
from sqlalchemy.sql.expression import delete

from . import models, schemas

def doctors_create(doctor: schemas.DoctorCreate, db: session) -> dict:
    doctor_model = models.Doctor(
        first_name = doctor.first_name,
        last_name = doctor.last_name,
        email = doctor.email,
        phone_number = doctor.phone_number,
        password = doctor.password
    )

    db.add(doctor_model)
    db.commit()
    db.refresh(doctor_model)
    
    return jsonable_encoder(doctor_model)


def doctors_read_all(db: session) -> list[dict]:
    db_doctors = db.query(models.Doctor).all()
    #           db.query(models.Doctor).filter(models.Doctor.id == id).first()

    for db_doctor in db_doctors:
        del db_doctor.__dict__['password']

    return db_doctors


def doctors_read_by_id(id: int, db: session) -> dict:
    db_doctor = db.query(models.Doctor).filter_by(id=id).first()
    #           db.query(models.Doctor).filter(models.Doctor.id == id).first()

    if not db_doctor:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"doctor with the id '{id}' not found")

    return db_doctor


def doctors_delete_by_id(id: int, db: session) -> dict:
    db_doctor = db.query(models.Doctor).filter_by(id=id).first()
    #           db.query(models.Doctor).filter(models.Doctor.id == id).first()

    if not db_doctor:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"doctor with the id '{id}' not found")

    db.delete(db_doctor)
    db.commit()

    return {'response': 'HTTP_204_NO_CONTENT'}


def doctors_updated_by_id(id: int, doctor: schemas.DoctorBase, db: session) -> dict:
    db_doctor = db.query(models.Doctor).filter_by(id=id)

    db_doctor.update(doctor)

    db.commit()
    db.refresh(db_doctor)

    return db_doctor


    




