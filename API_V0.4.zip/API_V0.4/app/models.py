from typing import List
from sqlalchemy import Column, ForeignKey, Integer, String, Boolean
from sqlalchemy.orm import relationship

from .database import Base

class Doctor(Base):
    __tablename__ = 'Doctors'

    first_name = Column(String)
    last_name = Column(String)
    email = Column(String, unique=True, index=True)
    phone_number = Column(String, unique=True, index=True)
    password = Column(String)

    id = Column(Integer, primary_key=True, unique=True, index=True, nullable=False)

    patients_id: Column(Integer, ForeignKey("patients.id"), default=None)

