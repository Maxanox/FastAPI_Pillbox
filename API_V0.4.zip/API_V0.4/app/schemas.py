from pydantic import BaseModel
from typing import Optional

class DoctorBase(BaseModel):
    first_name: str
    last_name: str
    email: str
    phone_number: str

class DoctorCreate(DoctorBase):
    password: str

class DoctorDb(DoctorBase):
    id: int
    password: str
    patients_id: Optional[list[dict]] = None

    class Config():
        orm_mode = True